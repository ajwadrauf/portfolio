# VELUNE campaign assembly

One Raspberry Ganache carton feeds a square storefront image and English and French 4:5 social ads. The carton, shadows, still-life plate and copy remain separate inputs. The same composition feeds both social ads, and each language has its own editable headline.

## Run in ComfyUI

1. Extract the ZIP. Copy the four PNGs in `Inputs` into the `input` directory in your ComfyUI installation.
2. Open ComfyUI and load `VELUNE-campaign-workflow.json`. The graph uses built-in nodes and was tested in ComfyUI 0.46.0 on a local CPU. It has no checkpoint or custom node dependency.
3. Run the workflow. This creates `velune-storefront`, `velune-social-en` and `velune-social-fr` PNGs in ComfyUI's output folder.
4. In **Edit French headline**, change the second line to **Des framboises.** and run again. Only the French typesetting, composite and export need to rerun on the same session.

`VELUNE-campaign-API.json` is the API equivalent. See the recorded exports on https://www.ajwadrauf.com/velune#campaign-assembly.

## What we checked

- The French headline went from “Le chocolat. Des framboises.” to “Le chocolat. Puis la framboise.” ComfyUI reused 25 of 28 nodes.
- The storefront and English exports were pixel-identical across both runs.
- The storefront render matched 335,256 pixels from the original front panel exactly. The two French renders matched across 869,400 pixels below the headline area, including the carton and shadow.
- The test uses one reference angle for one SKU. Each new carton shape, crop, language and market needs its own review.

The run IDs, output hashes and cached node IDs are in `run-evidence.json`.

## Image assets

The carton was cut out from the existing VELUNE reference. The storefront and social shadows are separate transparent inputs. The bonbon and berries were generated once in ChatGPT ImageGen as an unbranded plate that the graph reads from disk. The graph places the original carton and adds editable text. It takes no paid model calls to rerun.

### Social still-life prompt

> Create a photo-real 4:5 vertical background plate for a striking luxury raspberry chocolate social campaign. This image is a clean production asset, no words or lettering. Colors black cherry, cocoa, subtle warm pink and dark ruby. Understated and sculptural, refined fashion-editorial light from a large warm softbox upper left. Reserve the ENTIRE top 34 percent as calm dark burgundy negative space for a headline. Reserve the lower-left half from x=0% to 46%, y=48% to 91% as an open, seamless plum matte stone set for a rectangular carton that will be composited later, including a clear surface at the bottom. Keep a small, visually dramatic still-life group ONLY in the right half, between x=50% and x=96%, y=47% and y=83%: a single large glossy dark chocolate bonbon, elegantly cut through to reveal its fine textured raspberry ganache centre, plus two natural raspberries and a few restrained shards. Treat the cut face as a hero macro with complex highlights and dark cocoa shell. Large bonbon front-right anchored to the table; no tall pedestal. The fruit feels like an accent. Beautiful cinematic contrast, realistic edible textures, soft grain, intentional quiet space. Nothing overlaps the left placement area or the top 34 percent. No product box, carton, branded objects, person, lettering, type, border, or overlay.
