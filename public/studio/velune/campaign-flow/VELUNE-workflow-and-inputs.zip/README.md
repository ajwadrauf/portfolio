# VELUNE campaign assembly

The Raspberry Ganache carton is the lead product in the social layout. The two smaller chocolates come directly from the illustration printed on that same carton. They have a separate source, silhouette, scale and placement in ComfyUI.

## Run the graph

1. Copy the five PNGs in `Inputs` into your ComfyUI installation's `input` directory.
2. Load `VELUNE-campaign-workflow.json` and select **Run**. It was verified with the built-in nodes in ComfyUI 0.46.0 on a local CPU.
3. The graph exports a 1200 × 1200 storefront image and English and French 1080 × 1350 social ads.
4. Edit the second French line in **Edit French headline** and run again in the same session to isolate the language revision. With a warm cache, the headline, French composite and French export are the only three nodes that rerun.

`VELUNE-campaign-API.json` contains the equivalent request graph. `run-evidence.json` records the actual baseline and revision receipts, cached node IDs, output hashes and pixel checks.

## Art direction

The carton is 544 × 724 in the social layout and the chocolate layer is 240 × 181, about 44% of the carton width. The burgundy background was cropped from the unoccupied area of the original product reference. The independent shadow layer follows the carton and chocolate bases at their recorded positions. If you reposition a layer or change its scale, align its shadow with the new placement.

The evidence includes 6,993 interior chocolate pixels verified against the original print artwork before scaling. Across the recorded French headline revision, the other two exports stayed pixel-identical and all 869,400 pixels below the headline region matched.
