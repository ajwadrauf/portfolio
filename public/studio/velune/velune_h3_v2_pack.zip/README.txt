VELUNE v2 — corrected nine-image H3 Max reference pack

Upload the nine JPEGs from images/ in numeric order. Add the unchanged video as Video 1.
Use 01_h3_max_prompt.txt with H3 Max Reference: 15 seconds, 16:9, 768p, External soundtrack.
H3 accepts at most nine images, three videos and three audio clips, and twelve files combined. This pack uses nine images + one video. Do not attach the SVG report, collage, old portraits or audio as extra references.
The JPEGs retain their original dimensions. Nine supplied PNGs were converted to high-quality JPEG; the two older chocolate studies remain archived on the website but are not in this upload pack.
source_filenames.json identifies every original file and the excluded collage.

The elevenlabs files are direction, not generated sound. Keep music-as-reference off. Generate/audition sound separately in Ad Lab and align it to the accepted picture.
The exact report SVG is for final compositing over S11 (10.083–13.083s). It is not automatically inserted into a generated MP4. Review package lettering in the final take.
Loading the example does not spend or overwrite older projects. No new film was generated while preparing this pack. The Seedance example toggle is deferred.
